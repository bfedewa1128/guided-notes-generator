---
name: guided-notes-generator
description: Generates student Guided Notes for a lesson or a whole module, matching the layout of a sample Guided Notes file the teacher provides. Use when a teacher asks for guided notes, fill-in-the-blank notes, or a note-taking guide for a lesson or module.
---

# Guided Notes Generator

Create Guided Notes for one lesson or every lesson in a module, in the same format as a sample the teacher already uses.

## 1. Collect the inputs

Ask for these, in this order, and wait for each upload before moving on:

1. **A sample Guided Notes file** that is accepted in the teacher's courses. It can be an empty template or one that is already filled out. This sets the layout, headings, blank style, and tone to copy.
2. **The lesson or module content** to build the notes from. The teacher can upload a single lesson or an entire module at once. If the content is in a format that can't be read directly, suggest the teacher extract the text first (for example with Llama Tools) and upload that.
3. **Page length**: ask whether the notes should stay within a certain number of pages.
4. **File type**: ask whether they want a Word document, a Google Doc, or a PDF.

## 2. Build the notes

- Follow the sample's structure closely: same section order, heading style, question or blank format, and level of detail.
- Draw every term, fact, and example from the uploaded lesson content only. Do not add outside material.
- Turn the lesson's key vocabulary, concepts, and takeaways into blanks, prompts, or short-answer items in the style the sample uses.
- Respect the page length the teacher gave.
- If a whole module was uploaded, split it so **each lesson gets its own separate document**, named after the lesson.
- If the sample was filled out, also offer an answer key.

## 3. Deliver

- Produce the file type the teacher chose (Word document, Google Doc, or PDF), one file per lesson.
- Give a one-line summary of what was created (lessons covered, page count) and offer to adjust length, difficulty, or formatting.
